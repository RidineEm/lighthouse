using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    public void GameStart()
    {
        SceneManager.LoadScene("Game"); // Game �� ��ȯ
    }
    public void GameExit()
    {
        Application.Quit(); //���α׷� ����
    }
}
